package tes.scenes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import tes.controllers.UserController;
import tes.interfaces.ShowScene;

public class RegisterScene implements ShowScene {
    private Scene scene;
    private Stage stage;
    
    public RegisterScene(Stage stage) {
        this.stage = stage;
        createScene();
    }
    
    private void createScene() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(40));
        layout.setAlignment(Pos.CENTER);
        layout.setId("register-container");
        
        Label titleLabel = new Label("REGISTER");
        titleLabel.setId("register-title");
        
        Label subtitleLabel = new Label("Create New Account");
        subtitleLabel.setId("register-subtitle");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setId("register-input");
        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setId("register-input");
        
        Label messageLabel = new Label("");
        
        Button registerButton = new Button("REGISTER");
        registerButton.setId("register-button");
        
        Button backToLoginButton = new Button("Already have account? Login");
        backToLoginButton.setId("register-login-link");
        
        registerButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            
            if (UserController.isUsernameTaken(username)) {
                messageLabel.setText("Username already exists!");
                messageLabel.setId("message-error");
                return;
            }
            
            if (UserController.registAdd(username, password)) {
                new LoginScene(stage).show();
                
            } else {
                messageLabel.setText("Registration failed! Please try again.");
                messageLabel.setId("message-error");
            }
        });
        
        backToLoginButton.setOnAction(e -> {
            new LoginScene(stage).show();
        });
        
        layout.getChildren().addAll(
            titleLabel,
            subtitleLabel,
            usernameField,
            passwordField,
            messageLabel,
            registerButton,
            backToLoginButton
        );
        
        scene = new Scene(layout);
        
        scene.getStylesheets().add(getClass().getResource("/styles/style.css").toExternalForm());
    }
    
    @Override
    public void show() {
        stage.setScene(scene);
    }
}