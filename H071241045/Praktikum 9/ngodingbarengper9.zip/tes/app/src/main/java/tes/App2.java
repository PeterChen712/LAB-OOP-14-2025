package tes;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// Perpindahan scene dalam 1 file
public class App2 extends Application {
    
    private Stage stage;
    
    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        
        // Scene 1
        createScene1();
        
        stage.setTitle("Simple Scene Navigation");
        stage.setWidth(300);
        stage.setHeight(200);
        stage.show();
    }
    
    private void createScene1() {
        Label label1 = new Label("This is Scene 1");
        Button button1 = new Button("Go to Scene 2");
        button1.setOnAction(e -> createScene2());
        
        VBox layout1 = new VBox(20);
        layout1.setAlignment(Pos.CENTER);
        layout1.getChildren().addAll(label1, button1);
        
        Scene scene1 = new Scene(layout1);
        stage.setScene(scene1);
    }
    
    private void createScene2() {
        Label label2 = new Label("This is Scene 2");
        Button button2 = new Button("Back to Scene 1");
        button2.setOnAction(e -> createScene1());
        
        VBox layout2 = new VBox(20);
        layout2.setAlignment(Pos.CENTER);
        layout2.getChildren().addAll(label2, button2);
        
        Scene scene2 = new Scene(layout2);
        stage.setScene(scene2);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
