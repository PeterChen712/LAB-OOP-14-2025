package tes.interfaces;

public interface ShowScene {
    void show();
}