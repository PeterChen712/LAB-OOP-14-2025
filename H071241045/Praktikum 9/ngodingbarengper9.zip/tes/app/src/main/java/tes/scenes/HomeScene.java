package tes.scenes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import tes.controllers.UserController;
import tes.interfaces.ShowScene;
import tes.models.User;

public class HomeScene implements ShowScene {
    private Scene scene;
    private Stage stage;
    private User currentUser;
    
    public HomeScene(Stage stage, User user) {
        this.stage = stage;
        this.currentUser = user;
        createScene();
    }
    
    private void createScene() {
        VBox layout = new VBox(30);
        layout.setPadding(new Insets(40));
        layout.setAlignment(Pos.CENTER);
        layout.setId("home-container");
        
        Label titleLabel = new Label("HOME DASHBOARD");
        titleLabel.setId("home-title");
        
        Label welcomeLabel = new Label("Welcome, " + currentUser.getUserName() + "!");
        welcomeLabel.setId("home-welcome");
        
        VBox userInfo = new VBox(15);
        userInfo.setAlignment(Pos.CENTER);
        userInfo.setId("home-user-info");
        
        Label userTitleLabel = new Label("USER INFORMATION");
        userTitleLabel.setId("home-info-title");
        
        Label userIdLabel = new Label("User ID: " + currentUser.getId());
        userIdLabel.setId("home-info-text");
        
        Label usernameLabel = new Label("Username: " + currentUser.getUserName());
        usernameLabel.setId("home-info-text");
        
        userInfo.getChildren().addAll(userTitleLabel, userIdLabel, usernameLabel);
        
        VBox editSection = new VBox(15);
        editSection.setAlignment(Pos.CENTER);
        editSection.setId("home-edit-section");
        
        Label editTitleLabel = new Label("EDIT ACCOUNT");
        editTitleLabel.setId("home-edit-title");
        
        TextField editUsernameField = new TextField();
        editUsernameField.setPromptText("New Username");
        editUsernameField.setText(currentUser.getUserName());
        editUsernameField.setId("home-edit-input");
        
        PasswordField editPasswordField = new PasswordField();
        editPasswordField.setPromptText("New Password");
        editPasswordField.setId("home-edit-input");
        
        Label editMessageLabel = new Label("");
        
        editSection.getChildren().addAll(editTitleLabel, editUsernameField, editPasswordField, editMessageLabel);
        
        HBox buttonContainer = new HBox(20);
        buttonContainer.setAlignment(Pos.CENTER);
        
        Button saveButton = new Button("SAVE CHANGES");
        saveButton.setId("home-save-button");
        
        Button deleteButton = new Button("DELETE ACCOUNT");
        deleteButton.setId("home-delete-button");
        
        Button logoutButton = new Button("LOGOUT");
        logoutButton.setId("home-logout-button");
        
        buttonContainer.getChildren().addAll(saveButton, deleteButton, logoutButton);
        
        saveButton.setOnAction(e -> {
            String newUsername = editUsernameField.getText().trim();
            String newPassword = editPasswordField.getText().trim();
            
            if (newUsername.isEmpty()) {
                editMessageLabel.setText("Username cannot be empty!");
                editMessageLabel.setId("message-error");
                return;
            }
            
            if (!newUsername.equals(currentUser.getUserName()) && UserController.isUsernameTaken(newUsername)) {
                editMessageLabel.setText("Username already exists!");
                editMessageLabel.setId("message-error");
                return;
            }
            
            boolean success = false;
            
            if (!newPassword.isEmpty()) {
                
                boolean usernameUpdated = UserController.updateUsername(currentUser.getId(), newUsername);
                boolean passwordUpdated = UserController.updateUserPassword(currentUser.getId(), newPassword);
                success = usernameUpdated && passwordUpdated;
            } else {
                success = UserController.updateUsername(currentUser.getId(), newUsername);
            }
            
            if (success) {
                editMessageLabel.setText("Account updated successfully!");
                editMessageLabel.setId("message-success");
                
                currentUser = new User(currentUser.getId(), newUsername);
                welcomeLabel.setText("Welcome, " + currentUser.getUserName() + "!");
                usernameLabel.setText("Username: " + currentUser.getUserName());
                
                editPasswordField.clear();
            } else {
                editMessageLabel.setText("Failed to update account!");
                editMessageLabel.setId("message-error");
            }
        });
        
        deleteButton.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Account");
            alert.setHeaderText("Are you sure you want to delete your account?");
            alert.setContentText("This action cannot be undone!");
            
            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    boolean deleted = UserController.deleteUser(currentUser.getId());
                    
                    if (deleted) {
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                        successAlert.setTitle("Account Deleted");
                        successAlert.setHeaderText("Account deleted successfully!");
                        successAlert.setContentText("You will be redirected to login page.");
                        successAlert.showAndWait();
                        
                        new LoginScene(stage).show();
                    } else {
                        Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                        errorAlert.setTitle("Delete Failed");
                        errorAlert.setHeaderText("Failed to delete account!");
                        errorAlert.setContentText("Please try again later.");
                        errorAlert.showAndWait();
                    }
                }
            });
        });
        
        logoutButton.setOnAction(e -> {
            new LoginScene(stage).show();
        });
        
        layout.getChildren().addAll(titleLabel, welcomeLabel, userInfo, editSection, buttonContainer);
        
        scene = new Scene(layout);
        
        scene.getStylesheets().add(getClass().getResource("/styles/style.css").toExternalForm());
    }
    
    @Override
    public void show() {
        stage.setScene(scene);
    }
}