package tes;

import javafx.application.Application;
import javafx.stage.Stage;
import tes.scenes.LoginScene;

public class App3 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("User Management System");
        primaryStage.setWidth(600);
        primaryStage.setHeight(650);
        primaryStage.setResizable(false);
        
        LoginScene loginScene = new LoginScene(primaryStage);
        loginScene.show();
        
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}