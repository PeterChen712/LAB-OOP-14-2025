package tes.scenes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import tes.controllers.UserController;
import tes.interfaces.ShowScene;
import tes.models.User;

public class LoginScene implements ShowScene {
    private Scene scene;
    private Stage stage;
    
    public LoginScene(Stage stage) {
        this.stage = stage;
        createScene();
    }
    
    private void createScene() {
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(40));
        layout.setAlignment(Pos.CENTER);
        layout.setId("login-container");
        
        Label titleLabel = new Label("LOGIN");
        titleLabel.setId("login-title");
        
        Label subtitleLabel = new Label("Welcome Back!");
        subtitleLabel.setId("login-subtitle");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setId("login-input");
        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setId("login-input");
        
        Label messageLabel = new Label("");
        
        Button loginButton = new Button("LOGIN");
        loginButton.setId("login-button");
        
        Button registerButton = new Button("Don't have account? Register");
        registerButton.setId("login-register-link");
        
        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();
            
            if (username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please fill all fields!");
                messageLabel.setId("message-error");
                return;
            }
            
            User authenticatedUser = UserController.validasiLogin(username, password);
            
            if (authenticatedUser != null) {
                messageLabel.setText("Login successful!");
                messageLabel.setId("message-success");
                
                new HomeScene(stage, authenticatedUser).show();
            } else {
                messageLabel.setText("Invalid username or password!");
                messageLabel.setId("message-error");
            }
        });
        
        registerButton.setOnAction(e -> {
            new RegisterScene(stage).show();
        });
        
        layout.getChildren().addAll(
            titleLabel,
            subtitleLabel,
            usernameField,
            passwordField,
            messageLabel,
            loginButton,
            registerButton
        );
        
        scene = new Scene(layout);
        
        scene.getStylesheets().add(getClass().getResource("/styles/style.css").toExternalForm());
    }
    
    @Override
    public void show() {
        stage.setScene(scene);
    }
}