package tes;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class App extends Application {
    final private static int Width = 800;
    final private static int Length = 600;

    @Override
    public void start(Stage primaryStage) {

        // Bagian 1- ROOT
        // Group root = new Group();
        // Scene scene = new Scene(root, Color.WHITE);

        // //Bagian 2 - LAYOUT
        // Scene scene;
        // Label label1 = new Label("Label 1");
        // Label label2 = new Label("Label 2");
        // Button button1 = new Button("Button 1");
        // Button button2 = new Button("Button 2");

        // //VBOX
        // VBox vBox = new VBox();
        // vBox.getChildren().addAll(label1, label2);

        // //HBOX
        // HBox hBox = new HBox();
        // hBox.getChildren().addAll(label1, label2);

        // //GRIDPANE
        // GridPane gridPane = new GridPane();
        // gridPane.add(label1, 0, 0);
        // gridPane.add(label2, 1, 0);
        // gridPane.add(button1, 0, 1);
        // gridPane.add(button2, 1, 1);
        // gridPane.setHgap(10);
        // gridPane.setVgap(10);

        // //BORDERPANE
        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(label1);
        // borderPane.setBottom(label2);
        // borderPane.setLeft(button1);
        // borderPane.setRight(button2);
        // BorderPane.setAlignment(label1, Pos.CENTER);

        // // STACKPANE
        // StackPane stackPane = new StackPane();
        // stackPane.getChildren().addAll(label1, label2, button1, button2);

        // //FLOWPANE
        // FlowPane flowPane = new FlowPane();
        // flowPane.getChildren().addAll(label1, label2, button1, button2);
        // flowPane.setHgap(10);
        // flowPane.setVgap(10);
        // flowPane.setAlignment(Pos.CENTER);

        // //ANCHORPANE
        // AnchorPane anchorPane = new AnchorPane();
        // anchorPane.getChildren().addAll(button1, button2);
        // AnchorPane.setTopAnchor(button1, 10.0);
        // AnchorPane.setLeftAnchor(button1, 10.0);
        // AnchorPane.setBottomAnchor(button1, 10.0);
        // AnchorPane.setRightAnchor(button1, 10.0);

        // scene = new Scene(anchorPane, Color.WHITE);

        // Bagian 3 - NODE

        //TEXT CONTROLS
        // // LABEL
        // Scene scene;
        // Label label = new Label("Hello World!");
        // label.setTextFill(Color.BLACK);

        // // BUTTON
        // Button button = new Button("Click Me");
        // button.setOnAction(
        //         event -> label.setText("Button Clicked!"));

        // //TEXT
        // Text text = new Text("This is a text");
        // text.setFill(Color.BLUE);

        // // TextField - input teks satu baris
        // TextField textField = new TextField();
        // textField.setPromptText("Enter text here");

        // // TextArea - input teks multi-baris
        // TextArea textArea = new TextArea();
        // textArea.setPrefRowCount(5);
        // textArea.setWrapText(true);

        // // PasswordField - input password
        // PasswordField passwordField = new PasswordField();
        // passwordField.setPromptText("Enter password");

        // VBox vBox = new VBox(10);
        // vBox.getChildren().addAll(label, button, text, textField, textArea, passwordField);

        // scene = new Scene(vBox, Color.WHITE);



        //Bagian 4 - styling with css
        Scene scene;
        Label label = new Label("Hello World!");
        
        // Menggunakan inline CSS
        // label.setStyle("-fx-font-size: 24px; -fx-text-fill: blue;");
        
        //Menggunakan file CSS eksternal
        // label.getStyleClass().add("my-label"); // selector berdasarkan class
        
        // label.setId("my-label"); // selector berdasarkan id
        
        scene = new Scene(new Group(label), Color.WHITE);
        scene.getStylesheets().add(getClass().getResource("/styles/style.css").toExternalForm());





        primaryStage.setTitle("Hello World!");
        primaryStage.setWidth(Width);
        primaryStage.setHeight(Length);
        
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
