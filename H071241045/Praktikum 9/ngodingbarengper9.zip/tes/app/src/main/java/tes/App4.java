package tes;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import tes.config.DbConfig;
import tes.controllers.UserController;

public class App4 extends Application{

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        Scene scene = new Scene(new Group());
        primaryStage.setScene(scene);

        primaryStage.setTitle("Database Connection Example");
        primaryStage.setWidth(400);
        primaryStage.setHeight(300);
        primaryStage.setResizable(false);
        primaryStage.show();

        System.out.println(UserController.validasiLogin("user1", "123"));
        System.out.println(UserController.validasiLogin("user1", "1234"));
        System.out.println(UserController.validasiLogin("user2", "123"));

    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
